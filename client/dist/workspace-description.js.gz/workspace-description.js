/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "server:dev":
/*!******************!*\
  !*** server:dev ***!
  \******************/
/***/ (() => {

throw new Error("Module build failed: UnhandledSchemeError: Reading from \"server:dev\" is not handled by plugins (Unhandled scheme).\nWebpack supports \"data:\" and \"file:\" URIs by default.\nYou may need an additional plugin to handle \"server:\" URIs.\n    at /Users/deandraper/hr/sdc/workspace-description-service/node_modules/webpack/lib/NormalModule.js:741:26\n    at Hook.eval [as callAsync] (eval at create (/Users/deandraper/hr/sdc/workspace-description-service/node_modules/tapable/lib/HookCodeFactory.js:33:10), <anonymous>:6:1)\n    at Hook.CALL_ASYNC_DELEGATE [as _callAsync] (/Users/deandraper/hr/sdc/workspace-description-service/node_modules/tapable/lib/Hook.js:18:14)\n    at Object.processResource (/Users/deandraper/hr/sdc/workspace-description-service/node_modules/webpack/lib/NormalModule.js:738:9)\n    at processResource (/Users/deandraper/hr/sdc/workspace-description-service/node_modules/loader-runner/lib/LoaderRunner.js:220:11)\n    at iteratePitchingLoaders (/Users/deandraper/hr/sdc/workspace-description-service/node_modules/loader-runner/lib/LoaderRunner.js:171:10)\n    at runLoaders (/Users/deandraper/hr/sdc/workspace-description-service/node_modules/loader-runner/lib/LoaderRunner.js:397:2)\n    at NormalModule.doBuild (/Users/deandraper/hr/sdc/workspace-description-service/node_modules/webpack/lib/NormalModule.js:728:3)\n    at NormalModule.build (/Users/deandraper/hr/sdc/workspace-description-service/node_modules/webpack/lib/NormalModule.js:877:15)\n    at /Users/deandraper/hr/sdc/workspace-description-service/node_modules/webpack/lib/Compilation.js:1246:12");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module doesn't tell about it's top-level declarations so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["server:dev"]();
/******/ 	
/******/ })()
;
//# sourceMappingURL=workspace-description.js.map